# 使用

## windows环境

打开redis，导入sql，即可运行